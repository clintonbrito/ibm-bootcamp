import { Component } from '@angular/core';
import { Pessoa } from './model/pessoa';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'aula5b5';
  indexSelecionado:number|null = null;
  pessoa: Pessoa = new Pessoa();

  listaPessoas:Pessoa[]=[
    {
      nome: 'Yan',
      idade: 20,
      email: 'yan@ibm.com'
    },
    {
      nome: 'Ana',
      idade: 19,
      email: 'ana@ibm.com'
    },
    {
      nome: 'Antonio',
      idade: 18,
      email: 'antonio@ibm.com'
    },
    {
      nome: 'Theo',
      idade: 17,
      email: 'theo@ibm.com'
    },
  ];

  testeClick():void{
    alert('vc clicou! o titulo é: ' + this.title);
    console.log("estou clicando!");
  }

  salvar():void{
    alert("Os dados do "+ this.pessoa.nome +" foram salvos!");
    this.listaPessoas.push(this.pessoa);
    this.limpar();
  }

  limpar():void{
    this.pessoa = new Pessoa();
    this.indexSelecionado = null;
  }

  selecaoAlterar(index: number):void {
    this.indexSelecionado = index;
    this.pessoa = this.listaPessoas[index];
  }

  alterar():void {
    this.listaPessoas[this.indexSelecionado!]= this.pessoa;
    alert("Os dados do "+ this.pessoa.nome +" foram alterados!");
    this.limpar();
  }

  excluir(index: number): void{
    this.listaPessoas.splice(index, 1);
  }

}
