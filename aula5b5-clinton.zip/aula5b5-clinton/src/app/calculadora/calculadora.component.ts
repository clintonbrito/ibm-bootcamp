import { Component } from '@angular/core';

@Component({
  selector: 'app-calculadora',
  templateUrl: './calculadora.component.html',
  styleUrls: ['./calculadora.component.scss']
})
export class CalculadoraComponent {
  expressao: string = '';
  memoria: string | null = '';
  resultado: string | null = '0';

  adicionarNaMemoria(valor: string): void {
    this.expressao += valor;
    this.atualizarMemoria();
  }

  atualizarMemoria(): void {
    this.memoria = this.expressao || '0';
    this.resultado = this.memoria;
  }

  calcularResultado(): void {
    this.memoria = eval(this.expressao);
    this.resultado = this.memoria;
  }

  limparMemoria(): void {
    this.expressao = '';
    this.atualizarMemoria();
  }

}
