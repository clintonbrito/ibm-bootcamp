export class Pessoa {
    nome?:string|null;
    idade?:number|null;
    email?:string|null;

    constructor(nome?: string, idade?: number, email?:string){
        this.nome = nome;
        this.idade = idade;
        this.email = email;
    }
}