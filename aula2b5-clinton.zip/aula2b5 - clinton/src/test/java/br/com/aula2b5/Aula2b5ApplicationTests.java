package br.com.aula2b5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula2b5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
