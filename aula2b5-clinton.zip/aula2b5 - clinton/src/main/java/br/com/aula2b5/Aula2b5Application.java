package br.com.aula2b5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula2b5Application {

	public static void main(String[] args) {
		SpringApplication.run(Aula2b5Application.class, args);
	}

}
